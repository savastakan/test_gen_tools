
#include "FSM.h"
#include "Graph.h"
#include "types.h"

#include<queue>

//#define DEBUG
#include "Debug.h"
//#define HSI
#define MAXCOST 10000

void yyparse(void);

FSM fsm;

int main(int argc, char *argv[]) {
  if (argc < 2) {
    cerr << "Usage: " << argv[0] << "opts m" << endl <<
            "   opts = 0 for SPY method and 1 for HSI" << endl <<
            "   m = number of states in the implementation" << endl;
  }
  yyparse();
  fsm.setup();
  GraphNode::setNumChildren(fsm.numInputs);
  int options = atoi(argv[1]);
  int ishsi = options & 1;
  int useverified = options & 2;
  DEBUG_ASSERT(not useverified);
  int m = atoi(argv[2]);
  int n = fsm.numStates;
  int g = m - n;
  #ifdef DEBUG
  fsm.printOn(cout);
  #endif
  Graph mcomp(fsm);
  map<int, set<vector<int> > > hsi;
  for (int s1 = 0; s1 < n; s1++){
    for (int s2 = s1 + 1; s2 < n; s2++) {
      const vector<int> &gamma = fsm.getGamma(s1, s2);
      if (gamma.size() == 0) {
        cerr << "Not reduced" << endl;
        exit(-1);
      }
      hsi[s1].insert(gamma);
      hsi[s2].insert(gamma);
    }
  }
  set<GraphNode *> coveredTests;
  set<pair<int, int> > coveredTransitions;
  map<int, vector<GraphNode *> > blocks;
  queue<GraphNode *> qu;
  set<int> covered;
  qu.push(mcomp.getRoot());
  while(qu.size() > 0) {
    GraphNode *n = qu.front();
    qu.pop();
    int s = n->state;
    covered.insert(s);
    blocks[s].push_back(n);
    coveredTests.insert(n);
    for (int x = 0; x < fsm.numInputs; x++) {
      int s1 = fsm.nextState[fsm.calcPos(s, x)];
      if (covered.count(s1) == 0) {
        covered.insert(s1);
        GraphNode *n1 = mcomp.addNode(n, x);
        coveredTransitions.insert(make_pair(s, x));
        qu.push(n1);
      }
    }
  }
  #ifdef DEBUG
  for (int s = 0; s < n; s++){
    cout << "state " << fsm.intToState[s];
//    for(set<vector<int> >::const_iterator it = hsi[s1].begin(); it != hsi[s1].end(); it++) {
//      const vector<int> &seq = *it;
      for(vector<GraphNode *>::const_iterator its = blocks[s].begin(); its != blocks[s].end(); its++) {
        mcomp.printSeqFromLast(":", *its, ",");
      }
//      cout << ", ";
//    }
    cout << endl;
  }
  #endif
  for (int s = 0; s < n; s++) {
    GraphNode *node = blocks[s][0];
    for(set<vector<int> >::const_iterator it = hsi[s].begin(); it != hsi[s].end(); it++) {
      const vector<int> &seq = *it;
      mcomp.addNode(node, seq);
    }
  }
  vector<pair<int, int> > transitions;
  for (int l = 1; l <= n; l++) {
    for (int s = 0; s < n; s++) {
      for (int x = 0; x < fsm.numInputs; x++) {
        int s1 = fsm.nextState[fsm.calcPos(s, x)];
        if (blocks[s1][0]->level == l) {
          pair<int, int> transition = make_pair(s, x);
          transitions.push_back(transition);
        }
      }
    }
  }

  for(vector<pair<int, int> >::const_iterator it = transitions.begin(); it != transitions.end(); it++) {
    pair<int, int> transition = *it;
    if (coveredTransitions.count(transition) != 0) {
      continue;
    }
    int s = transition.first;
    int x = transition.second;
    int sprime = fsm.nextState[fsm.calcPos(s, x)];
    GraphNode *alpha = blocks[s][0];
    GraphNode *beta = blocks[sprime][0];
    #ifdef DEBUG
    mcomp.printSeqFromLast("alpha ", alpha, ":"); cout << endl;
    cout << "(" << fsm.intToState[s] << " ," << fsm.intToInput[x] << ") " << endl;
    mcomp.printSeqFromLast("beta ", beta, ":"); cout << endl;
    #endif
    map<pair<int, int>, vector<int> > shortestVerifiedTransfer;
    if(useverified) {
      for(set<pair<int, int> >::const_iterator itt = coveredTransitions.begin(); itt != coveredTransitions.end(); itt++) {
        pair<int, int> transition = *itt;
        int s1 = transition.first;
        int x1 = transition.second;
        int s2 = fsm.nextState[fsm.calcPos(s1, x1)];
        if (s1 != s2) {
          vector<int> transfer;
          transfer.push_back(x1);
          shortestVerifiedTransfer[make_pair(s1, s2)] = transfer;
        }
      }
      for(int s1 = 0; s1 < n; s1++) {
        for(int s2 = 0; s2 < n; s2++) {
          if (s1 != s2) {
            for(int s3 = 0; s3 < n; s3++) {
              if(shortestVerifiedTransfer[make_pair(s1, s2)].size() >
                  shortestVerifiedTransfer[make_pair(s1, s3)].size() +
                  shortestVerifiedTransfer[make_pair(s3, s2)].size()) {
                vector<int> transfer = shortestVerifiedTransfer[make_pair(s1, s3)];
                for(vector<int>::const_iterator itsv = shortestVerifiedTransfer[make_pair(s3, s2)].begin(); 
                    itsv != shortestVerifiedTransfer[make_pair(s3, s2)].end();
                    itsv++) {
                  transfer.push_back(*itsv);
                }
              }
            }
          }
        }
      }
    }
//    for(int s1 = 0; s1 < n; s1++) {
//      DEBUG_INSPECT(s1);
//      for(int s2 = 0; s2 < n; s2++) {
//        DEBUG_INSPECT(s2);
//        DEBUG_INSPECT(shortestVerifiedTransfer[make_pair(s1, s2)]);
//      }
//    }
    queue<vector<int> > gammas;
    gammas.push(vector<int>());
    while(gammas.size() > 0) {
      vector<int> gamma = gammas.front();
      DEBUG_INSPECT(gamma);
      gammas.pop();
      if (gamma.size() < g) {
        for (int x = 0; x < fsm.numInputs; x++) {
          vector<int> newgamma = gamma;
          newgamma.push_back(x);
          gammas.push(newgamma);
        }
      }
      vector<int> xgamma;
      xgamma.push_back(x);
      int sgamma = sprime;
      for(vector<int>::const_iterator it = gamma.begin(); it != gamma.end(); it++) {
        xgamma.push_back(*it);
        sgamma = fsm.nextState[fsm.calcPos(sgamma, *it)];
      }
      for(set<vector<int> >::const_iterator it = hsi[sgamma].begin(); it != hsi[sgamma].end(); it++) {
        vector<int> xgammasigma = xgamma;
        vector<int> gammasigma = gamma;
        const vector<int> &sigma = *it;
        for(vector<int>::const_iterator its = sigma.begin(); its != sigma.end(); its++) {
          xgammasigma.push_back(*its);
          gammasigma.push_back(*its);
        }
        DEBUG_INSPECT(xgammasigma);
        DEBUG_INSPECT(gammasigma);
        GraphNode *alphaprime;
        GraphNode *betaprime;
        if(ishsi) {
          alphaprime = alpha;
          mcomp.addNode(alpha, xgammasigma);
        } else {
          alphaprime = NULL;
          int alphacost = MAXCOST;
          for(vector<GraphNode *>::const_iterator ita = blocks[s].begin(); ita != blocks[s].end(); ita++) {
            int cost = mcomp.calcCost(*ita, xgammasigma);
            if (cost < alphacost) {
              alphaprime = *ita;
              alphacost = cost;
              if (cost == 0) {
                break;
              }
            }
          }
          vector<int> pi;
          if (useverified and alphacost > xgammasigma.size()) {
            mcomp.collectLeafes(false);
            vector<GraphNode *> &leafes = mcomp.getLeafes();
            for(vector<GraphNode *>::const_iterator itl = leafes.begin(); itl != leafes.end(); itl++) {
              GraphNode *leaf = *itl;
              if(coveredTests.count(leaf) != 0) {
                const vector<int> &transfer = shortestVerifiedTransfer[make_pair(leaf->state, s)];
                if (transfer.size() > 0) {
                  if (transfer.size() + xgammasigma.size() < alphacost) {
                    //DEBUG_ASSERT(0);
                    alphaprime = leaf;
                    pi = transfer;
                    alphacost = transfer.size() + xgammasigma.size();
                  }
                }
              }
            }
          }
          //Pi is verified
          for(vector<int>::const_iterator itpi = pi.begin(); itpi != pi.end(); itpi++) {
            alphaprime = mcomp.addNode(alphaprime, *itpi);
            coveredTests.insert(alphaprime);
            blocks[alphaprime->state].push_back(alphaprime);
          }
          mcomp.addNode(alphaprime, xgammasigma);
        }
        if(ishsi) {
          betaprime = beta;
          mcomp.addNode(beta, gammasigma);
        } else {
          betaprime = NULL;
          int betacost = MAXCOST;
          for(vector<GraphNode *>::const_iterator itb = blocks[sprime].begin(); itb != blocks[sprime].end(); itb++) {
            int cost = mcomp.calcCost(*itb, gammasigma);
            if (cost < betacost) {
              betaprime = *itb;
              betacost = cost;
              if (cost == 0) {
                break;
              }
            }
          }
          vector<int> pi;
          if (useverified and betacost > gammasigma.size()) {
            mcomp.collectLeafes(false);
            vector<GraphNode *> &leafes = mcomp.getLeafes();
            for(vector<GraphNode *>::const_iterator itl = leafes.begin(); itl != leafes.end(); itl++) {
              GraphNode *leaf = *itl;
              if(coveredTests.count(leaf) != 0) {
                const vector<int> &transfer = shortestVerifiedTransfer[make_pair(leaf->state, sprime)];
                if (transfer.size() > 0) {
                  if (transfer.size() + gammasigma.size() < betacost) {
                    betaprime = leaf;
                    pi = transfer;
                    betacost = transfer.size() + gammasigma.size();
                  }
                }
              }
            }
          }
          //Pi is verified
          for(vector<int>::const_iterator itpi = pi.begin(); itpi != pi.end(); itpi++) {
            betaprime = mcomp.addNode(betaprime, *itpi);
            coveredTests.insert(betaprime);
            blocks[betaprime->state].push_back(betaprime);
          }
          mcomp.addNode(betaprime, gammasigma);
        }
      }
    }
  #ifdef DEBUG
    cout << "covered trans ";
    for(set<pair<int, int> >::const_iterator it = coveredTransitions.begin(); it != coveredTransitions.end(); it++) {
      cout << "(" << fsm.intToState[(*it).first] << " ," << fsm.intToInput[(*it).second] << ") ";
    }
    cout << endl;
  #endif
    coveredTransitions.insert(transition);
    if (not ishsi) {
      queue<GraphNode *> toProcess;
      for(vector<GraphNode *>::const_iterator ita = blocks[s].begin(); ita != blocks[s].end(); ita++) {
        toProcess.push(*ita);
      }
      while(toProcess.size() > 0) {
        GraphNode *n = toProcess.front();
        toProcess.pop();
        int s = n->state;
        for(int x = 0; x < fsm.numInputs; x++) {
          if (coveredTransitions.count(make_pair(s, x)) != 0) {
            GraphNode * n1 = n->children[x];
            if (n1 != NULL and coveredTests.count(n1) == 0) {
              blocks[n1->state].push_back(n1);
              coveredTests.insert(n1);
              toProcess.push(n1);
            }
          }
        }
      }
    }
  }
  #ifdef DEBUG
  for (int s1 = 0; s1 < n; s1++){
    cout << "state " << s1;
    for(set<vector<int> >::const_iterator it = hsi[s1].begin(); it != hsi[s1].end(); it++) {
      const vector<int> &seq = *it;
      for(vector<int>::const_iterator its = seq.begin(); its != seq.end(); its++) {
        cout << " " << *its;
      }
      cout << ", ";
    }
    cout << endl;
  }
  mcomp.printWithoutPrefix(">>");
  vector<int> seq;
  cout << mcomp.calcCost(mcomp.getRoot(), seq) << endl;
  #endif
//  mcomp.printWithoutPrefix(">>");
  mcomp.printWithoutPrefix("", "");

//  cout << ishsi << " " << n << " " << m << " " << fsm.numInputs << " " << fsm.numOutputs << " ";
//  cout << mcomp.totalLength() << " ";
  mcomp.collectLeafes(false);
//  cout << mcomp.getLeafes().size() << endl;
  exit(0);
}
