#ifndef __TYPES_H__
#define __TYPES_H__

using namespace std;
#include <vector>
#include <set>
#include <ostream>
#include <iterator>
#include <algorithm>
typedef vector<int> inputSequence;

template<class t>
ostream & operator << (ostream &os, const vector<t> &s) {
  os << "[<" << s.size() << ">";
  copy(s.begin(), s.end(), ostream_iterator<t>(os, ","));
  os << "]";
  return os;
}

template<class t>
ostream & operator << (ostream &os, const set<t> &s) {
  os << "{<" << s.size() << ">";
  copy(s.begin(), s.end(), ostream_iterator<t>(os, ","));
  os << "}";
  return os;
}

template<class t1, class t2>
ostream & operator << (ostream &os, const pair<t1, t2> & pa) {
  os << "(" << pa.first << "," << pa.second << ")";
  return os;
}

#endif
