#ifndef __GRAPH_H__
#define __GRAPH_H__

#include "FSM.h"

#include <istream>

struct GraphNode {
  GraphNode(GraphNode *par, int pi, int s);
  GraphNode *parent;
  int level;
  int parentInput;
  int state;
  GraphNode **children;
  bool isLeaf() const;
  ~GraphNode();
  static void setNumChildren(int numC);
  private:
  static int numChildren;
};

class Graph {
  public:
    Graph(FSM &fsm);
    GraphNode * setRoot(int state); 
    GraphNode * getRoot() {
      return parent;
    }
    GraphNode * addNode(GraphNode *, int pi, int state); 
    GraphNode * addNode(GraphNode *, const vector<int> &);
    GraphNode * getNode(GraphNode *, const vector<int> &) const;
    GraphNode * addNode(GraphNode *n, int pi);
    int calcCost(GraphNode *n, const vector<int> &s);
    void calcLongestChain(GraphNode *, GraphNode *, int, vector<GraphNode *> &);
    void spanStateCounting(int);
    void spanTransitionCover();
    void spanReducedStateCounting();
    void spanSingleTransitionCover();
    void spanTransitionTour();
    void spanWp1stPhase();
    void spanWp2ndPhase();
    long int totalLength();
    long int totalLengthWithoutPrefix();
    void printWithoutPrefix(const string &, const string &sep = " ");
    void printSeqFromLast(const string &, GraphNode *last, const string &sep = " ");
    void printSeqFromLastWithStates(const string &, GraphNode *last);
    void collectLeafes(bool cached = true);
    vector<GraphNode *> & getLeafes() {
      return leafes;
    }
    void getInputSeqs(set<vector<int> > &s);
    void getInputSeqs(GraphNode *p, vector<int> &c, set<vector<int> > &s); 
    void getInputSeq(GraphNode *last, vector<int> &);
    void getInputSeq(GraphNode *last, vector<GraphNode *> &);
    void getInputSeq(GraphNode *last, vector<string> &);
    void readFrom(istream &is);
    void incrRand();
    GraphNode * compareOutput(FSM &m1, FSM &m2, long &ne, long &nd, bool onlyFirst = false);
    void getAllInputOutputSequences(vector<pair<int, int> > &, int reset = -1);
    void getTraversedTransitions(bool *trans);
    ~Graph();

  protected:
    vector<GraphNode *> leafes;
    GraphNode * parent;
  private:
     FSM &fsm;
    void printWithoutPrefixAux(const string &, GraphNode *, const string &);
    void calcLongestChainAux(GraphNode *, GraphNode *, int, vector<GraphNode *> &);
    void spanStateCountingAux(int, GraphNode *, GraphNode *);
    long int totalLengthAux(GraphNode *, int depth);
    long int totalLengthWithoutPrefixAux(GraphNode *);
    void collectLeafesAux(GraphNode *);
    void getAllInputOutputSequences(GraphNode *node, vector<pair<int, int> > &io, vector<pair<int, int> >aux, int reset);
    void getTraversedTransitionsAux(GraphNode *node, bool *trans);
};

void spanUpToNthLevelAux(const FSM &fsm, Graph *graph, GraphNode * node, int level, int maxLevel);

Graph * spanUpToNthLevel(const FSM &fsm, int maxLevel);

#endif
