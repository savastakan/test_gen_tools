
#include "Debug.h"

timeb lasttime;
timeb thistime;

