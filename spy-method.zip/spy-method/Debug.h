#ifndef __DEBUG_H__
#include <sys/timeb.h>
#ifdef DEBUG

extern timeb lasttime;
extern timeb thistime;

#define DEBUG_TIME ftime(&thistime); lasttime = thistime; cerr << __FILE__ << ":" << __LINE__ << " " << thistime.time << " " << thistime.millitm << endl;

#define DEBUG_DIFF_TIME lasttime = thistime; ftime(&thistime); cerr << __FILE__ << ":" << __LINE__ << " " << (1000 * thistime.time + thistime.millitm) - (1000 * lasttime.time + lasttime.millitm) << endl; 

#define DEBUG_INSPECT(x) cerr << __FILE__ << ":" << __LINE__ << " " << #x << " = " << (x) << endl;

#define DEBUG_ASSERT(x) if (!(x)) { cerr << __FILE__ << ":" << __LINE__ << " " << #x << " failed!!" << endl; int * a = NULL; *a = 1; exit(1); }

#define DEBUG_PASS cerr << __FILE__ << ":" << __LINE__ << endl;

#define DEBUG_EXEC(x) x;

#else

#define DEBUG_TIME

#define DEBUG_DIFF_TIME

#define DEBUG_INSPECT(x) 

#define DEBUG_ASSERT(x) 

#define DEBUG_PASS 

#define DEBUG_EXEC(x)

#endif

#include <iostream>
#include <fstream>
#include <set>
#include <iterator>


#endif
